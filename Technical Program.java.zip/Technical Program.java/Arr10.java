class Arr10{
    
    public static void main(String args[]){
      
      int a=90;
          a=67; 
          a=66;
      System.out.println(a);
      a=77;
      System.out.println(a);
      
           
    }
}
