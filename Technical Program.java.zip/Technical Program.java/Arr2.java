class Arr2{
    
    public static void main(String args[]){
        
       if(false){                            
           System.out.println("Hi");
       }
       else{
           System.out.println("Bye");
       }
        
        
    }
}
