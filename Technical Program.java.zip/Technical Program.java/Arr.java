   class Arr{
   public static void main(String args[]){
        int i=1;
       
        while(i<=10){
           
            if(i==5){
                System.out.println("hello");
                continue;
            }
            else{
                System.out.println("Bye");
            }
            i++;
        }
   
          
    }
}
