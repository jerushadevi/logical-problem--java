class Arr3{
    
    public static void main(String args[]){
        
       while(true){
           System.out.println("Hello");
       }
        
        
    }
}
