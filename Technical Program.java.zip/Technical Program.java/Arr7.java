class Arr7{
    
    public static void main(String args[]){
        
        int i=1;
       while(i<=10){
          
          if(i==6){  
           System.out.println("Hello");
           break;
          }
          else{
              System.out.println("Bye");
          }
          i++;
       }
        
        
    }
}
