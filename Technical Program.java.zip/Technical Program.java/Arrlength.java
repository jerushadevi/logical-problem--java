class Arrlength{
    
    public static void main(String args[]){
      
      int arr[]={23,45,67,78,90,65,33,22};
      
      for(int i=0;i<arr.length;i++){
          
          System.out.print(arr[i]+"  ");
      }
    }
}
